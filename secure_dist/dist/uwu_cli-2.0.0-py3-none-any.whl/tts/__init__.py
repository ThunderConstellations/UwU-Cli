# tts/__init__.py
"""
TTS module for UwU-CLI
Provides text-to-speech functionality
"""

# This file makes the tts directory a Python package 