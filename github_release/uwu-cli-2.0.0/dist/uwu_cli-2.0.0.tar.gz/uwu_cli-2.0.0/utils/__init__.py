# utils/__init__.py
"""
Utilities module for UwU-CLI
Provides access to all utility functions
"""

# This file makes the utils directory a Python package 